# AiXel-MIDI-Player
MIDI player interface en open source capable de lire directement les progressions d'accords générées par AiXel en notation ABC et de jouer ces progressions en streaming.
